using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class orbit : MonoBehaviour
{
    //Assign a GameObject in the Inspector to rotate around

    public GameObject target;
    public float OrbitSpeedH;
    public float OrbitSpeedV;
    void Update()
    {
        OrbitSpeedH = -100f * Input.GetAxis("Horizontal");
        OrbitSpeedV = -100f * Input.GetAxis("Vertical");

        
        // Spin the object around the target at 20 degrees/second.
        transform.RotateAround(target.transform.position, Vector3.up, OrbitSpeedH * Time.deltaTime);
        transform.RotateAround(target.transform.position, Vector3.left, OrbitSpeedV * Time.deltaTime);


    }
}
