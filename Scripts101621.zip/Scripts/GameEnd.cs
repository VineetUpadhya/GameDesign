using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameEnd : MonoBehaviour
{
    public GameObject breaker;
    public GameObject gun;
    BallMaker ballcount;
    DestroyBlock end;
    bool check = true;
    // Start is called before the first frame update
    void Start()
    {
       
        ballcount = gun.GetComponent<BallMaker>();
        end = breaker.GetComponent<DestroyBlock>();
    }

    // Update is called once per frame
    void Update()
    {
        if (check)
        {
                if ((end.health <= 0) || (ballcount.ammo <= 0))
                {
                    UnityEngine.Debug.Log("Game Over");
                }
            check = false;
        }
    }
}
 
