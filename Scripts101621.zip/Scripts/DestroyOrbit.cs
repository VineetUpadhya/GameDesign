using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyOrbit : MonoBehaviour
{
    public Renderer rend;
    public int health = 3;
    public float timer = 4f;
    bool timerrun = false;
    public bool dest = false;
    Collider bc;
    // Start is called before the first frame update
    void Start()
    {
        rend = GetComponent<Renderer>();
        rend.enabled = true;
        bc = gameObject.GetComponent<Collider>();

    }

    // Update is called once per frame
    void Update()
    {
        if (dest)
        {
            if (timerrun)
            {
                if (timer >= 0)
                {
                    timer -= Time.deltaTime;
                }
                else
                {
                    rend.enabled = true;
                    bc.enabled = true;
                    dest = false;
                    timerrun = false;
                    health = 3;
                    timer = 0;
                }
            }


        }


    }
    private void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.tag == "MainBall")
        {
            health--;
            UnityEngine.Debug.Log("Planet Have " + health + " health");
            Destroy(other.gameObject);
            if (health <= 0)
            {
                rend.enabled = false;
                bc.enabled = false;
                dest = true;
                timerrun = true;

            }


        }
    }


}

