using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallMaker : MonoBehaviour
{
    public Rigidbody secondBall;
    public float initialspeed = 150f;
    public float ammo = 10f;



    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonUp("Fire1"))
        {
            if (ammo > 0)
            {


                //creates newball rigidbody that copyies prefab
                Rigidbody newBall = Instantiate(secondBall, transform.position, transform.rotation) as Rigidbody;
                GameObject soccerGo = newBall.gameObject;
                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                RaycastHit hit;
                if (Physics.Raycast(ray, out hit))
                {
                    newBall.transform.LookAt(hit.point);
                    newBall.velocity = newBall.transform.forward * initialspeed;
                }
                Destroy(soccerGo, 15f);
                ammo--;
                
            }
            else
            {
                UnityEngine.Debug.Log("Out Of Ammo -  Game Over");
            }


        }
    }
}
