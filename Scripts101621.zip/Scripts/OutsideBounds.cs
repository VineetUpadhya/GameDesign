using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OutsideBounds : MonoBehaviour
{
    public float homeHeight = 7f;
    private void OnTriggerEnter(Collider other)
    {
        if(other.tag == "MainBall")
        {
            Debug.Log("your shoot went out of bounds");
            //returns back to home position
            Vector3 homePosition = new Vector3(2.8f, homeHeight, -34.38f);
            Rigidbody rb = other.gameObject.GetComponent<Rigidbody>();
            rb.velocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
            Transform trans = other.gameObject.GetComponent<Transform>();
            trans.position = homePosition;
        }
    }
}
