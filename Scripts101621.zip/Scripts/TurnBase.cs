using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    float randx;
    float randz;
    public float speed = 600f;
    float time = 0;
    void RandomDir()
    {
        randx = Random.Range(-250f, 250f);
        randz = Random.Range(-250f, 250f);
    }
    // Start is called before the first frame update
    void Start()
    {
        Vector3 position = transform.position;  
    }

    // Update is called once per frame
    void Update()
    {
        
        if (Input.GetButtonUp("Fire1"))
        {
            time += Time.deltaTime;
            if(time >= 5)
            {
                transform.Translate(randx, 0, randz);
            }
        }
    }
}
