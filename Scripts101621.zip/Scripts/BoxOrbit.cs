using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoxOrbit : MonoBehaviour
{
    //Assign a GameObject in the Inspector to rotate around

    public GameObject target;
    public float OrbitSpeed = 20f;
    public float OrbitStep;
    public float OrbitDir;
    bool timer;
    public bool fire = false;
    float orbittemp = 2f;
    float timeelap = 0f;
    void Update()
    {


        /*OrbitStep = Random.Range(2f, 15f);
        OrbitDir = Random.Range(-1f, 1f);
        if(OrbitDir < 0)
        {
            OrbitDir = -1f;
        }
        else if(OrbitDir > 0)
        {
            OrbitDir = 1f;
        }
        else
        {
            OrbitDir = 0;
        }

        // Spin the object around the target at 20 degrees/second.
        if (Input.GetButtonUp("Fire1"))
        {
            fire = true;
        }
        if (fire){
            yield return new WaitForSeconds(5);
            timer = true;
            if (timer) {
                transform.RotateAround(target.transform.position, Vector3.left, OrbitSpeed * Time.deltaTime * OrbitDir);
                yield return new WaitForSeconds(OrbitStep);
            }
            else
            {
                fire = false;
            }

        }*/
        StartCoroutine(move());

        
        
           
           



    }
    IEnumerator move()
    {
        OrbitStep = Random.Range(2f, 15f);
        OrbitDir = Random.Range(-1f, 1f);
        if (OrbitDir < 0)
        {
            OrbitDir = -1f;
        }
        else if (OrbitDir > 0)
        {
            OrbitDir = 1f;
        }
        else
        {
            OrbitDir = 0;
        }

        // Spin the object around the target at 20 degrees/second.
        if (Input.GetButtonUp("Fire1"))
        {
            fire = true;
        }
        if (fire)
        {
            yield return new WaitForSeconds(5);
            timer = true;
            if (timer)
            {
                transform.RotateAround(target.transform.position, Vector3.left, OrbitSpeed * Time.deltaTime);

                yield return new WaitForSeconds(2);
                timer = false; 
            }
            else
            {
                fire = false;
            }

        }
    }

}
